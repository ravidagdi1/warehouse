const express = require('express');
const authController = require('./../controllers/authController');
const masterListController = require('./../controllers/masterListController')
const router = express.Router();


router
  .route('/')
  .get(masterListController.getAllList)
  .post(
    masterListController.uploadProductPhoto,
    masterListController.resizeProductPhoto,
    masterListController.createListItem
   );

router
  .route('/:id')
  .get(masterListController.getListItem)
  .put(masterListController.updateListeItem)
  .delete(masterListController.deleteListeItem);

module.exports = router ;