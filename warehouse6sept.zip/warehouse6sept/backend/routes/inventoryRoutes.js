const express = require('express');
const authController = require('../controllers/authController');
const inventoryController = require('../controllers/inventoryController')
const router = express.Router();


router
  .route('/')
  .get(authController.protect,authController.restrictTo('admin','user'),inventoryController.getAllInventory)
  .post( authController.protect,authController.restrictTo('admin','user'), inventoryController.createInventoryItem);

router
  .route('/:id')
  .get(inventoryController.getInventoryItem)
  .put(inventoryController.updateInvetoryItem)
  .delete(inventoryController.deleteInventroyItem);

module.exports = router ;