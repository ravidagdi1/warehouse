const multer = require('multer');
const sharp = require('sharp');
const MasterList = require('../models/masterListModel');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/appError');
const factory = require('./handlerFactory');

const multerStorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/img/product');
  },
  filename: (req, file, cb) => {
    const ext = file.mimetype.split('/')[1];
    cb(null, `product-${Date.now()}.${ext}`);
  }
});
// const multerStorage = multer.memoryStorage();

const multerFilter = (req, file, cb) => {
  
  if (file.mimetype.startsWith('image')) {
    console.log(file)
    cb(null, true);
  } else {
    cb(new AppError('Not an image! Please upload only images.', 400), false);
  }
};

const upload = multer({
  storage: multerStorage,
  fileFilter: multerFilter
});

exports.uploadProductPhoto = upload.single('photo');

exports.resizeProductPhoto = catchAsync(async (req, res, next) => {
  if (!req.file) return next(); // If no file is uploaded, skip this middleware

  const ext = 'jpeg'; // Convert the image format to jpeg
  const filename = `product-${Date.now()}.${ext}`; // Generate a new filename for the resized image

  // Use sharp to resize the image from the path
  await sharp(req.file.path)
    .resize(500, 500)
    .toFormat(ext)
    .jpeg({ quality: 90 })
    .toFile(`public/img/product/${filename}`); // Save the resized image to disk

  req.body.image = filename; // Store the new filename in req.body.image for further processing

  next(); // Proceed to the next middleware
});

const filterObj = (obj, ...allowedFields) => {
  const newObj = {};
  Object.keys(obj).forEach(el => {
    if (allowedFields.includes(el)) newObj[el] = obj[el];
  });
  return newObj;
};


exports.createListItem = factory.createOne(MasterList)

exports.getListItem = factory.getOne(MasterList);
exports.getAllList = factory.getAll(MasterList);

// Do NOT update passwords with this!
exports.updateListeItem = factory.updateOne(MasterList);
exports.deleteListeItem = factory.deleteOne(MasterList);
