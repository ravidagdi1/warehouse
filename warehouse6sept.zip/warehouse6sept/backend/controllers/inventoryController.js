
const Inventory = require('../models/inventoryModel');
const factory = require('./handlerFactory');
const catchAsync = require('../utils/catchAsync');
const User = require('../models/userModel');


exports.createInventoryItem = catchAsync(async (req, res, next) => {
    console.log(req.body)
    req.body.user = req.user;

    const doc = await Inventory.create(req.body);
    if (!doc) {
      console.log('log')
      return next(new AppError('No document found with that ID', 404));
    }
    res.status(201).json({
      status: 'success',
      data: {
        data: doc
      }
    });
});
exports.getAllInventory = catchAsync(async (req,res,next)=>{
  console.log(req.user);
  const user = await User.findById(req.body.user);
  const filter = {};

  if(user.role == 'admin'){
    filter = {}
  }else{
    filter = {user : user._id}
  }
  const inventory = await Inventory.find(filter)

  res.status(201).json({
    status: 'success',
    data: {
      data: doc
    }
  });
})
exports.getInventoryItem = factory.getAll(Inventory);

exports.updateInvetoryItem = factory.updateOne(Inventory);
exports.deleteInventroyItem = factory.deleteOne(Inventory);
