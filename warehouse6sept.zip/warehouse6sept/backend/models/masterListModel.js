const crypto = require('crypto');
const mongoose = require('mongoose');
const validator = require('validator');
const bcrypt = require('bcryptjs');

const masterListSchema = new mongoose.Schema({
  partNo: {
    type: Number,
    required: [true, 'Please tell us your name!'],
    unique: true
  },
  image: {
    type: String,
    required: [true, 'Please Provide Image!']
  },
  category:{
    type: String,
  },
  subCategory:{
    type:String
  },
  description:{
    type:String
  },
  unit:{
    type:String
  },
  remark:{
    type:String
  },
  active: {
    type: Boolean,
    default: false,
    select: true
  }
});


// userSchema.pre(/^find/, function(next) {
//   // this points to the current query
//   this.find({ active: { $ne: false } });
//   next();
// });


const MasterList = mongoose.model('MasterList', masterListSchema);

module.exports = MasterList;
