
const mongoose = require('mongoose');

const storeSchema = new mongoose.Schema({
  name:{
    type:String,
    lowercase: true,
    unique:true,
    required:[true,'Store must have a name!']
  },
  location:{
    type:String,
    lowercase: true,
    required:[true,'Store must have a location !']
  },
  status:{
    type: String,
      default:'active',
      enum: {
        values: ['active', 'inactive'],
        message: 'Status is either: active, inactive !'
      }
  }
});


// userSchema.pre(/^find/, function(next) {
//   // this points to the current query
//   this.find({ active: { $ne: false } });
//   next();
// });



const Store = mongoose.model('Store', storeSchema);

module.exports = Store;
