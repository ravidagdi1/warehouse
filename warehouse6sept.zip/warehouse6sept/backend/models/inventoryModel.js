
const { type } = require('@testing-library/user-event/dist/type');
const mongoose = require('mongoose');

const inventorySchema = new mongoose.Schema({
  masterItem:{
    type:mongoose.Schema.ObjectId,
    ref:'MasterList',
    required:[true,'Please Select Item !']
    
  },
  store:{
    type:mongoose.Schema.ObjectId,
    ref:'Store',
    required:[true,'Please Select Store !']
  },
  user:{
     type:mongoose.Schema.ObjectId,
     ref:'User',
     required:[true,'Please Select User !']
  },
  qtyAuth:{
    type:Number
  },
  criticalStockQty:{
    type:Number
  },
  reciveQty:{
    type:Number
  },
  totalRecive:{
    type:Number,
    default: 0,
    required:true
  },
  transfer:{
    type:Number,
    default: 0,
  },
  currentStock:{
    type:Number,
    default: 0,
  },
  totalMiv:{
    type:Number,
    default: 0,
  },
  lp:{
    type:Number,
    default:0
  },
  urgentRequirement:{
    type:Boolean,
    default:false
  },
  status:{
    type: String,
      default:'pending',
      enum: {
        values: ['pending', 'confirm', 'delivered'],
        message: 'Status is either: pending, confirm, delivered'
      }
  },
  remark:{
    type:String,
  },
  active: {
    type: Boolean,
    default: false,
    select: true
  }
});


// userSchema.pre(/^find/, function(next) {
//   // this points to the current query
//   this.find({ active: { $ne: false } });
//   next();
// });

inventorySchema.pre(/^find/, function(next) {
  this.populate({
    path: 'masterItem',
    select: '-__v -active -id'
  });

  next();
});

const Inventory = mongoose.model('Inventory', inventorySchema);

module.exports = Inventory;
