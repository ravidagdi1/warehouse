import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import Login from './component/Auth/Login';
import Dashboard from './component/Dashboard';
import Header from './component/Header/Header';
import Footer from './component/Header/Footer';
import SideBar from './component/Header/SideBar';
import UserManager from './component/UserManager';
import Trainer from './component/Trainer';
import Notification from './component/Notification';
import AddNotification from './component/Add Model/AddNotification';
import AddHomeSlider from './component/Add Model/AddHomeSlider';
import AddFaq from './component/Add Model/AddFaq';
import AddBanner from './component/Add Model/AddBanner';
import Banner from './component/Banner';
import Contect from './component/Contect';
import Apointment from './component/Apointment';
import HomeSlider from './component/HomeSlider';
import Settings from './component/Settings';
import Faq from './component/Faq';
import AboutUs from './component/AboutUs';
import PrivacyPolicy from './component/PrivacyPolicy';
import TermCondition from './component/TermAndCondition';
import HowToImage from './component/HowToImage';
import Feedback from './component/Feedback';
import AddAdmin from './component/Add Model/AddAdmin';
import AdminUser from './component/AdminUser';
import PushNotification from './component/PushNotification';
import PushNotificationList from './component/PushNotificationList';
import Earning from './component/Earning';
import AddYogaCategory from './component/Add Model/AddYogaCategory';
import YogaCategory from './component/YogaCategory';
import AddYogaBanner from './component/Add Model/AddYogaBanner';
import YogaBanner from './component/YogaBanner';
import UserPermission from './component/UserPermission';
import Location from './component/Location';
import AddLocation from './component/Add Model/AddLocation';
import SignUp from './component/Auth/SignUp';
import MasterList from './component/MasterList';
import AddMasterItem from './component/Add Model/AddMasterItem';
import Inventory from './component/Inventory';
import Store from './component/Store';

const PrivateRoute = ({ children, isAuthenticated, role, requiredRole }) => {
  if (isAuthenticated === null) {
    return <div>Loading...</div>; // Or any other loading indicator
  }
  if (!isAuthenticated) {
    return <Navigate to="/" />;
  }
  if (requiredRole && !requiredRole.includes(role)) {
    return <Navigate to="/dashboard" />; // Or an appropriate "not authorized" page
  }
  return children;
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(null);
  const [role, setRole] = useState(null);

  useEffect(() => {
    // Check if the user is authenticated and get their role
    const token = localStorage.getItem('authToken');
    const userRole = localStorage.getItem('userRole'); // Assuming role is stored in local storage
    if (token && userRole) {
      setIsAuthenticated(true);
      setRole(userRole);
    } else {
      setIsAuthenticated(false);
    }
  }, [role]);

  return (
    <Router>
      {isAuthenticated && <SideBar />}
      {isAuthenticated && <Header />}
      <Routes>
        <Route
          path="/"
          element={
            isAuthenticated ? <Navigate to="/dashboard" /> : <Login setIsAuthenticated={setIsAuthenticated} setRole={setRole} />
          }
        />

      <Route
          path="/signup"
          element={
            isAuthenticated ? <Navigate to="/dashboard" /> : <SignUp setIsAuthenticated={setIsAuthenticated} setRole={setRole} />
          }
        />
         
        
        <Route
          path="/dashboard"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['storeKeeper']}>
           
              <Dashboard />
              </PrivateRoute>
          }
        />
        <Route
          path="/master"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['storeKeeper']}>
           
              <MasterList />
              </PrivateRoute>
          }
        />
        <Route
          path="/add-master-item"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['storeKeeper']}>
           
              <AddMasterItem />
              </PrivateRoute>
          }
        />
        <Route
          path="/inventory"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['storeKeeper']}>
           
              <Inventory />
              </PrivateRoute>
          }
        />
         <Route
          path="/store"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['storeKeeper']}>
              <Store />
            </PrivateRoute>
          }
        /> 
        <Route
          path="/privacy-policy"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <PrivacyPolicy />
            </PrivateRoute>
          }
        />
          <Route
          path="/term-condition"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <TermCondition />
            </PrivateRoute>
          }
        />
          <Route
          path="/user-permission"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <UserPermission />
            </PrivateRoute>
          }
         />
          <Route
          path="/how-it-work"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <HowToImage />
            </PrivateRoute>
          }
        />
           <Route
          path="/feedback"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <Feedback />
            </PrivateRoute>
          }
        />
        <Route
          path="/users"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'storeKeeper']}>
              <storeKeeperManager />
            </PrivateRoute>
          }
        />
        <Route
          path="/trainer"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'storeKeeper']}>
              <Trainer />
            </PrivateRoute>
          }
        />
        <Route
          path="/notification"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <Notification />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-notification"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <AddNotification />
            </PrivateRoute>
          }
        />
           <Route
          path="/faq-list"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <Faq />
            </PrivateRoute>
          }
        />
         <Route
          path="/add-faq"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <AddFaq />
            </PrivateRoute>
          }
        />
         <Route
          path="/homeslider"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <HomeSlider />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-home-slider"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <AddHomeSlider />
            </PrivateRoute>
          }
        />
        <Route
          path="/apointment"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <Apointment />
            </PrivateRoute>
          }
        />
        <Route
          path="/contect"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <Contect />
            </PrivateRoute>
          }
        />
         <Route
          path="/pushNotification"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <PushNotification />
            </PrivateRoute>
          }
        />
         <Route
          path="/push-notification-list"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <PushNotificationList />
            </PrivateRoute>
          }
        />
        <Route
          path="/admin-user"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <AdminUser />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-admin-user"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <AddAdmin />
            </PrivateRoute>
          }
        />
          <Route
          path="/settings"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <Settings />
            </PrivateRoute>
          }
        />
        <Route
          path="/location"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <Location />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-location"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <AddLocation />
            </PrivateRoute>
          }
        />
        <Route
          path="/add-banner"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <AddBanner />
            </PrivateRoute>
          }
        />
        <Route
          path="/banner"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'human']}>
              <Banner />
            </PrivateRoute>
          }
        />
          <Route
        path="/add-yoga-category"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <AddYogaCategory />
            </PrivateRoute>
          }
            
        />
        <Route
          path="/yoga-category"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'Doctor']}>
              <YogaCategory/>
            </PrivateRoute>
          }
          
        />
           <Route
        path="/add-yoga-banner"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <AddYogaBanner />
            </PrivateRoute>
          }
            
        />
          <Route
          path="/yoga-banner"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin', 'Doctor']}>
              <YogaBanner/>
            </PrivateRoute>
          }
          
        />
         <Route
          path="/trainer-earning"
          element={
            <PrivateRoute isAuthenticated={isAuthenticated} role={role} requiredRole={['Admin']}>
              <Earning />
            </PrivateRoute>
          }
        />
       
      </Routes>
      {isAuthenticated && <Footer />}
    </Router>
  );
}

export default App;
