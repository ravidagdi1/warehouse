import React, { useState } from 'react';
import useAsync from '../hooks/useAsync';
import AppointmentServices from '../services/AppointmentServices';
import ViewTrainerEarning from './View Model/ViewEarning';
import Modal from 'react-modal';
import { utils, writeFile } from 'xlsx';

Modal.setAppElement('#root');

function TrainerEarning() {
  const { data, error, isLoading, run } = useAsync(AppointmentServices.getApointment);
  // console.log(">>>>>>>",data);
  const count = data?.data?.filter(earning => earning.status === 'approved').length;
  const [activeIndex, setActiveIndex] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");

  const handleViewDetails = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
    toggleActionMenu(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const toggleActionMenu = (index) => {
    setActiveIndex(index === activeIndex ? null : index); // Toggle the active index
  };

  function formatDateTime(isoString) {
    const date = new Date(isoString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  }

  function formatTime(isoString) {
    const date = new Date(isoString);
    const formattedTime = date.toLocaleTimeString();
    return formattedTime;
  }

  function downloadEarnings() {
    const formattedData = data?.data
      ?.filter(earning => earning.status === 'approved')
      ?.map((earning, index) => ({
        '#': index + 1,
        Image: process.env.REACT_APP_URL + (earning.trainer?.image || ''),
        Name: earning.user?.name || '',
        Age: earning.trainer?.age || '',
        Fee: earning.trainer?.fee || '',
        Date: formatDateTime(earning.duration?.date || ''),
        Time: formatTime(earning.duration?.date || ''),
        Address: earning.trainer?.address || '',
        'Trainer Name': earning.trainer?.name || '',
        'Complete Status': earning.completeStatus || '',
      }));

    const worksheet = utils.json_to_sheet(formattedData);
    const workbook = utils.book_new();
    utils.book_append_sheet(workbook, worksheet, 'Earnings');
    writeFile(workbook, 'Earnings.xlsx');
  }

  const filteredEarnings = data?.data?.filter(earning => 
    earning.status === 'approved' &&
    (earning.trainer?.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
    earning.user?.name.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <>
      <div className="right_col" role="main">
        <div className="title-box">
          <h2>Trainer Earning List <span className="badge bg-orange">{count}</span></h2>
        </div>
        <div className="sub-title-box">
          <div className="sub-title-box-left">
            <p>Earning</p>
          </div>
          <div className="sub-title-box-right">
            <button className="excel-btn" onClick={downloadEarnings}><img src="img/excel.svg" alt="" />Download</button>
          </div>
        </div>
        <div className="container-box px-0">
          <div className="container-box-top-header px-4">
            <div className="container-box-top-header-left-2">
              <input 
                type="search" 
                name="search" 
                placeholder="Search" 
                value={searchQuery} 
                onChange={(e) => setSearchQuery(e.target.value)} 
              />
              <button className="search-btn">Search</button>
            </div>
          </div>
          <div className="container-box-inner">
            <table id="example" className="table table-striped" style={{ width: '100%' }}>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Image</th>
                  <th>Trainer Name</th>
                  <th>Fee</th>
                  <th>Date</th>
                  <th>Address</th>
                  <th>User Name</th>
                  <th>Status</th>
                  <th>More Details</th>
                </tr>
              </thead>
              <tbody>
                {filteredEarnings?.map((earning, index) => (
                  <tr key={index}>
                    <td>{index + 1}</td>
                    <td>
                      <div className="product-img">
                        <img src={process.env.REACT_APP_URL + (earning?.trainer?.image || '')} alt="" />
                      </div>
                    </td>
                    <td>{earning?.trainer?.name || ''}</td>
                    <td>{earning?.trainer?.fee || ''}</td>
                    <td className="payment">{formatDateTime(earning.duration?.date || '')}</td>
                    <td className='address'>{earning?.trainer?.address || ''}</td>
                    <td>{earning?.user?.name || ''}</td>
                    <td>{earning?.status || ''}</td>
                    <td>
                      <button
                        className="view-details-btn"
                        onClick={() => handleViewDetails(earning)}
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <Modal
          isOpen={isModalOpen}
          onRequestClose={closeModal}
          contentLabel="User Details"
          className="modal-content"
          overlayClassName="modal-overlay"
        >
          <ViewTrainerEarning user={selectedUser} closeModal={closeModal} />
        </Modal>
      </div>
    </>
  );
}

export default TrainerEarning;
