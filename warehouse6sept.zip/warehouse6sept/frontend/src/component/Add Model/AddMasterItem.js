import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import NotificationServices from '../../services/NotificationServices';
import ProductServices from '../../services/ProductServices';
function AddMasterItem() {

  
  const [formValues, setFormValues] = useState({
    partNo: 0,
    category:" ",
    subCategory:' ',
    description: " ",
    unit:" ",
    remark: " ",
  });

  const [previewImage, setPreviewImage] = useState('img/placeholder-img.png'); // Placeholder image path


  // Handle form input changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value
    });
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
      setFormValues({
        ...formValues,
        photo: file,
      });
    }
  };
//   // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const formData = new FormData();
      console.log(formData);
    for (const key in formValues) {
      formData.append(key, formValues[key]);
    }
      console.log(formValues)
     const response = await ProductServices.AddProduct(formData);
      // Assuming updateContactDetail is a method in UserServices
      console.log(response);
      alert('Master List Added Successfully');
      } catch (error) {
      console.error('Failed to Master List details', error);
      alert('Failed to add Master List details');
    }
  };

  return (
    <>
    <div className="right_col" role="main">
        <div className="title-box">
          <h2>Add Master Item</h2>
          <div className="container-box-top-header-right">
            <Link className="list-banner-btn" to="/master">Master List</Link>
          </div>
        </div>
        <div className="container-box px-5">
          <div className="container-box-inner">
            <div className="page-details">
              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-lg-9 col-md-6">
                    <div className="input-field">
                      <label>Part No.</label>
                      <input type="number" name="partNo" className="form-control"  value={formValues.partNo} 
                        onChange={handleInputChange}  placeholder="" />
                    </div>
                  </div>
                  <div className="col-lg-9 col-md-6">
                    <div className="input-field">
                      <label>Category</label>
                      <input type="text" name="category" className="form-control"  value={formValues.category} 
                        onChange={handleInputChange}  placeholder="" />
                    </div>
                  </div>
                  <div className="col-lg-9 col-md-6">
                    <div className="input-field">
                      <label>SubCategory</label>
                      <input type="text" name="subCategory" className="form-control"  value={formValues.subCategory} 
                        onChange={handleInputChange}  placeholder="" />
                    </div>
                  </div>
                  
                  <div className="col-lg-9 col-md-6">
                    <div className="input-field">
                      <label>Unit</label>
                      <input type="text" name="unit" className="form-control"  value={formValues.unit} 
                        onChange={handleInputChange}  placeholder="" />
                    </div>
                  </div>
                  <div className="col-lg-9 col-md-6">
                    <div className="input-field">
                      <label>Remark</label>
                      <input type="text" name="remark" className="form-control"  value={formValues.remark} 
                        onChange={handleInputChange}  placeholder="" />
                    </div>
                  </div>
                  <div className="col-sm-12">
                    <div className="input-field">
                      <label>Description</label>
                      <textarea className="form-control video-desc" name="description"  value={formValues.description} 
                        onChange={handleInputChange} placeholder='' />                           
                    </div>
                  </div>
                  <div className="col-sm-12">
                    <div className="input-field">
                      <label>Upload<span className="red">*</span></label>
                      <input type="file" name="photo" className="form-control" onChange={handleFileChange} />
                      <p><span>Drop an image or Paste URL (upto resolution 1,500 x 1,500 px),</span> Supported formats: png, jpeg, jpg, webp</p>
                      <div className="file-preview text-center">
                        <img id="uploadFile" src={previewImage} alt="your image" />
                      </div>
                    </div>
                  </div>
                </div>
                <button className="submit-green-btn">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default AddMasterItem