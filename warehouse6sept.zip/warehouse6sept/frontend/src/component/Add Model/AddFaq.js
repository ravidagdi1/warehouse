import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import FaqServices from '../../services/FaqServices';

function AddFAQ() {
  const [faq, setFaq] = useState({
    title: '',
    description: '',
    userFor: 'all',
  });

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFaq({
      ...faq,
      [name]: value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await FaqServices.AddFaq(faq);
      if (response.status === true) {
        alert('FAQ added successfully');
        setFaq({
          title: '',
          description: '',
          userFor: 'all',
        });
      } else {
        alert('Something went wrong');
      }
    } catch (error) {
      console.error('Failed to add FAQ', error);
      alert('Failed to add FAQ');
    }
  };

  return (
    <div className="right_col" role="main">
      <div className="title-box">
        <h2>FAQs Add</h2>
        <div className="container-box-top-header-right">
          <Link className="list-banner-btn" to="/faq-list">List FAQs</Link>
        </div>
      </div>
      
      <div className="container-box px-5">
        <div className="container-box-inner">
          <div className="page-details">
            <form onSubmit={handleSubmit}>
              <div className="row">
                <div className="col-sm-6">
                  <div className="input-field">
                    <label>Select Type</label>
                    <select
                      name="userFor"
                      className="form-control"
                      value={faq.userFor}
                      onChange={handleInputChange}
                    >
                      <option value="User">User</option>
                      <option value="Trainer">Trainer</option>
                      <option value="all">All</option>
                    </select>
                  </div>
                </div>
                <div className="col-sm-12">
                  <div className="input-field">
                    <label>Frequently Asked Questions Title</label>
                    <input
                      type="text"
                      name="title"
                      className="form-control"
                      value={faq.title}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
                <div className="col-sm-12">
                  <div className="input-field">
                    <label>Answer</label>
                    <textarea
                      name="description"
                      className="form-control video-desc"
                      value={faq.description}
                      onChange={handleInputChange}
                    />
                  </div>
                </div>
              </div>
              <button className="submit-green-btn" type="submit">
                SUBMIT
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddFAQ;
