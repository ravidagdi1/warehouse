import React,{useState} from 'react';
import { Link } from 'react-router-dom';
import NotificationServices from '../../services/NotificationServices';
import LocationServices from '../../services/LocationServices';
function AddLocation() {

  
  const [formValues, setFormValues] = useState({
    location: '',
    city: '',
    image: '',
    state: '',
    latitude: '',
    longitude:'',
  });

  const [previewImage, setPreviewImage] = useState('img/placeholder-img.png'); // Placeholder image path


  // Handle form input changes
  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value
    });
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
      setFormValues({
        ...formValues,
        image: file,
      });
    }
  };
//   // Handle form submission
  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const formData = new FormData();
      
    for (const key in formValues) {
      formData.append(key, formValues[key]);
    }
      console.log(formValues)
     const response = await LocationServices.createLocation(formData);
      // Assuming updateContactDetail is a method in UserServices
 console.log(response);
      alert('Location Added Successfully');
      setFormValues({
        location: '',
        city: '',
        image: '',
        state: '',
        latitude: '',
        longitude:'',
      })
      } catch (error) {
      console.error('Failed to Location details', error);
      alert('Failed to add Location');
    }
  };

  return (
    <>
    <div className="right_col" role="main">
        <div className="title-box">
          <h2>Add Location</h2>
          <div className="container-box-top-header-right">
            <Link className="list-banner-btn" to="/location">Location List</Link>
          </div>
        </div>
        <div className="container-box px-5">
          <div className="container-box-inner">
            <div className="page-details">
              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-lg-6 col-md-6">
                    <div className="input-field">
                      <label>Location</label>
                      <input type="text" name="location" className="form-control"  value={formValues.location} 
                        onChange={handleInputChange}  placeholder=" ex- vaishali nagar" />
                    </div>
                  </div>
                  
                  <div className="col-lg-6 col-md-6">
                    <div className="input-field">
                      <label>City</label>
                      <input type="text" name="city" className="form-control"  value={formValues.city} 
                        onChange={handleInputChange}  placeholder="ex- Jaipur" />
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-6">
                    <div className="input-field">
                      <label>State</label>
                      <input type="text" name="state" className="form-control"  value={formValues.state} 
                        onChange={handleInputChange}  placeholder="ex - Rajasthan" />
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-6">
                    <div className="input-field">
                      <label>Latitude</label>
                      <input type="text" name="longitude" className="form-control"  value={formValues.longitude} 
                        onChange={handleInputChange}  placeholder="ex - 26.891819735734458" />
                    </div>
                  </div>
                  <div className="col-lg-6 col-md-6">
                    <div className="input-field">
                      <label>Longitude</label>
                      <input type="text" name="latitude" className="form-control"  value={formValues.latitude} 
                        onChange={handleInputChange}  placeholder="ex - 75.7919675521027" />
                    </div>
                  </div>
                  
                  <div className="col-sm-12">
                    <div className="input-field">
                      <label>Upload<span className="red"></span></label>
                      <input type="file" name="image" className="form-control" onChange={handleFileChange} />
                      <p><span>Drop an image or Paste URL (upto resolution 1,500 x 1,500 px),</span> Supported formats: png, jpeg, jpg, webp</p>
                      <div className="file-preview text-center">
                        <img id="uploadFile" src={previewImage} alt="your image" />
                      </div>
                    </div>
                  </div>
                </div>
                <button className="submit-green-btn">Add Location</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default AddLocation