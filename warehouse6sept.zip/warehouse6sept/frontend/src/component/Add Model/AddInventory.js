import React, { useState, useEffect } from 'react';
import HelpTogal from '../TogelButton/HelpTogal';
import NotificationServices from '../../services/NotificationServices';
import ProductServices from '../../services/ProductServices';

function AddInventory({ notification, closeModal, onSuccess }) {
  const [formValues, setFormValues] = useState({
    masterItem:notification?._id,
    partNo: 0,
    category: '',
    subCategory: '',
    description: '',
    unit: '',
    remark: " ",
    qtyAuth: 0,
    criticalStockQty:0
  });
  const [previewImage, setPreviewImage] = useState('img/placeholder-img.png'); 

  useEffect(() => {
    if (notification) {
      setFormValues({
        masterItem: notification?._id,
        partNo: notification?.partNo || 0,
    category: notification?.category || " ",
    subCategory: notification?.subCategory || " ",
    description: notification?.description || " ",
    unit: notification?.unit || " ",
    
      });
      if (notification?.image) {
        setPreviewImage('http://localhost:3001/img/product/' + notification?.image);
      }
    }
  }, [notification]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewImage(reader.result);
      };
      reader.readAsDataURL(file);
      setFormValues({
        ...formValues,
        image: file,
      });
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const formData = new FormData();
      for (const key in formValues) {
        if (key !== 'image' || formValues[key] instanceof File) {
          formData.append(key, formValues[key]);
        }
      }

      await ProductServices.AddInventory({
        masterItem:formValues.masterItem,
        qtyAuth:formValues.qtyAuth,
        criticalStockQty:formValues.criticalStockQty,
        remark:formData.remark
      });
      alert('Inventrory Added');
      onSuccess();
    } catch (error) {
      console.error('Failed to Add Inventory', error);
      alert('Failed to Add Inventory');
    }
  };

  return (
    <div className="modal fade edit-box show d-block" id="editModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Inventory Add</h5>
            <button type="button" className="btn-close" data-bs-dismiss="modal" onClick={closeModal} aria-label="Close" />
          </div>
          <div className="modal-body">
            <div className="container-box px-5">
              <div className="container-box-inner">
                <div className="page-details">
                  <form onSubmit={handleSubmit}>
                    <div className="row">
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Part No</label>
                          <input type="Number" name="partNo" className="form-control" value={formValues.partNo}  placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Category</label>
                          <input type="text" name="category" className="form-control" value={formValues.category}  placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Sub Category</label>
                          <input type="text" name="subCategory" className="form-control" value={formValues.subCategory}  placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Unit</label>
                          <input type="text" name="unit" className="form-control" value={formValues.unit}  placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-12 col-sm-12">
                        <div className="input-field">
                          <label>Description</label>
                          <textarea rows="3" style={{ height: 'auto' }} type="text" name="description" value={formValues.description}  className="form-control" placeholder="New notification" />
                        </div>
                      </div>
                      <div className="col-sm-9">
                        <div className="input-field">
                          <div className="file-preview text-center">
                            <img id="uploadFile" src={previewImage} alt="your image" />
                          </div>
                        </div>
                      </div>

                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Qty Auth</label>
                          <input type="number" name="qtyAuth" className="form-control" value={formValues.qtyAuth} onChange={handleInputChange}  placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Critical Stock Qty</label>
                          <input type="number" name="criticalStockQty" className="form-control" value={formValues.criticalStockQty} onChange={handleInputChange}   placeholder="" />
                        </div>
                      </div>
                      <div className="col-lg-9 col-md-6">
                        <div className="input-field">
                          <label>Remark4</label>
                          <input type="text" name="remark" className="form-control" value={formValues.remark} onChange={handleInputChange}   placeholder="" />
                        </div>
                      </div>
                    </div>
                    <button className="submit-green-btn">Update</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddInventory;
