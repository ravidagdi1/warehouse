import React from 'react'

function ViewTrainerEarning({ user  , closeModal}) {
  if (!user) return null;
  function formatDateTime(isoString) {
    const date = new Date(isoString);
    const formattedDate = date.toLocaleDateString();
    const formattedTime = date.toLocaleTimeString();
    return { date: formattedDate, time: formattedTime };
  }

  const url = 'uploads/'
  const { date, time } = formatDateTime(user.createdAt);
  return (
    <div className="modal fade viewbox edit-box show d-block"  id="manufacturerModal" tabIndex={-1} aria-labelledby="manufacturerModal" aria-hidden="true" >
        <div className="modal-dialog modal-dialog-centered">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="manufacturerModal">Details</h5>
              <button type="button" className="btn-close" onClick={closeModal} aria-label="Close"></button>
            </div>
            <div className="modal-body px-5">
              <div className="d-box mt-3 pt-1">
                <ul className="d-flex list-unstyled justify-content-between">
                <li><span>Name: </span>{user?.trainer?.name}</li>
                <li><span>Mobile No: </span> {user?.trainer?.mobileNo}</li>
                <li><span>State: </span> {user?.trainer?.state}</li>
                <li><span>District: </span> {user?.trainer?.district}</li>
                <li><span>City: </span> {user?.trainer?.city}</li>
                <li><span>Age: </span> {user?.trainer?.age}</li>
                <li><span>Fee :</span>{user?.trainer?.fee}</li>
                <li><span>User Name :</span>{user?.user?.name}</li>
                <li><span>Experience :</span>{user?.user?.experience}</li>
                <li><span>Registration date: </span>{date}</li>
                <div style={{ width: '100%' }}>
                  <li><span>Address: </span>{user?.trainer?.address}</li>
                </div>
              
                </ul>
               
            
              </div>
            </div>
          </div>
        </div>
      </div>
  )
}

export default ViewTrainerEarning