import React from 'react'
import HelpTogal from '../TogelButton/HelpTogal'

function ViewFeedback({ feedback  , closeModal ,onSuccess}) {
  function formatDateTime(isoString) {
    const date = new Date(isoString);
    return date.toLocaleDateString();
  }
  return (
    <div className="modal fade viewbox edit-box show d-block" id="helpViewModal" tabIndex={-1} aria-labelledby="helpViewModal" aria-hidden="true">
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title" id="helpViewModal">Details</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal"  onClick={closeModal} aria-label="Close" />
        </div>
        <div className="modal-body px-5">
          <div className="d-box mt-3 pt-1">
            <ul className="d-flex list-unstyled justify-content-between">
              <li><span>User Type : </span>{feedback?.userType}</li>
              <li><span>Rating: </span>{feedback?.rating}</li>
              <li><span>User Name : </span>{feedback?.user?.name}</li>
              <li><span>Contact: </span>{feedback?.user?.mobileNo}</li>
              <li><span>Created Date: </span>{formatDateTime(feedback?.createdAt)}</li>
             
            </ul>
          </div>
          <div className="address mt-4">
            <span>Message: </span>
            <span>{feedback?.message}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}

export default ViewFeedback