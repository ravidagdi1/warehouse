import React from 'react'

function ViewUser({ user, closeModal }) {
  console.log(">>>>>>>>", user);
  if (!user) return null;
  function formatDateTime(isoString) {
    const date = new Date(isoString);
    const formattedDate = date.toLocaleDateString();
    const formattedTime = date.toLocaleTimeString();
    return { date: formattedDate, time: formattedTime };
  }

  const url = 'uploads/'
  const { date, time } = formatDateTime(user.createdAt);
  return (
    <div className="modal fade viewbox edit-box show d-block" id="manufacturerModal" tabIndex={-1} aria-labelledby="manufacturerModal" aria-hidden="true" >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title" id="manufacturerModal">Details</h5>
            <button type="button" className="btn-close" onClick={closeModal} aria-label="Close"></button>
          </div>
          <div className="modal-body px-5">
            <div className="d-box mt-3 pt-1">
              <ul className="d-flex list-unstyled justify-content-between">
                <li><span>Name: </span>{user.name}</li>
                <li><span>Mobile No: </span> {user.mobileNo}</li>
                <li><span>State: </span> {user.state}</li>
                {/* <li><span>District: </span> {user?.district}</li> */}
                <li><span>City: </span> {user?.city}</li>
                <li><span>Spaicalization:</span> {user?.spaicalization?.length > 0 ? user.spaicalization.join(', ') : 'No Spaicalization available'}</li>
                <li><span>Age: </span> {user?.age}</li>
                <li><span>Avialablity: </span> {user?.availablity}</li>
                <li><span>Degree Details: </span> {user?.degreeDetails}</li>
                <li><span>Fee Type: </span> {user?.feeType}</li>
                <li><span>Offline Fee :</span>{user?.fee}</li>
                <li><span>Online Fee : </span> {user?.onlineFee}</li>
                <li><span>About You: </span> {user?.aboutYou}</li>
                <li><span>Experience :</span>{user?.expiriance}</li>

                <li><span>Registration date: </span>{date}</li>
                <li><span>URL: </span>{user?.youtubeLink}</li>
                <div style={{ width: '100%' }}>
                  <li><span>Address: </span>{user?.address}</li>
                </div>
                <li><span>Availability Day:</span> {user?.day?.length > 0 ? user.day.join(', ') : 'No days available'}</li>
                <li><span>Availability Time:</span> {user?.time?.length > 0 ? user.time.join(', ') : 'No times available'}</li>

                {/* {user.userType !== 'customer' && (
                  <>
                  <li><span>Details about {user.userType}: </span>{user?.profile?.detailAbout}</li>
                  <li><span>GST No* :   </span>{user?.profile?.gstNo}</li> 
                  <li><span>CIN No. : </span>{user?.profile?.cin}</li>
                  </>)}
                  {user.userType == 'serviceCenter' && (
                  <>
                  <li><span>Company Authorized : </span>{user?.profile?.authorization}</li>
                  </>
                )} */}
                {/* <li><span>Payment :</span>{user?.plan?.planName}</li>
                  <li><span>Fee :</span>{user?.plan?.planName}</li> */}
              </ul>
              {/* <div className="address mt-4">
                  <span><a href="#"><img src="img/google-map-icon.svg" /></a></span>
                  <span>{user?.address}</span>
                </div> */}
              {user.userType !== 'customer' && (
                <>

                  <div className="mt-5 d-box-grp">
                    <a href={user?.certificate ? `${process.env.REACT_APP_URL}${user.certificate}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="certificate" /> Certificate* </button></a>
                    <a href={user?.achievement ? `${process.env.REACT_APP_URL}${user.achievement}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="achievement" /> Achievement* </button></a>
                    <a href={user?.yogaPoses?.pose1 ? `${process.env.REACT_APP_URL}${user.yogaPoses.pose1}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="Yoga Pose 1" /> Yoga Pose 1* </button></a>
                    <a href={user?.yogaPoses?.pose2 ? `${process.env.REACT_APP_URL}${user.yogaPoses.pose2}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="Yoga Pose 2" /> Yoga Pose 2*</button></a>
                    <a href={user?.yogaPoses?.pose3 ? `${process.env.REACT_APP_URL}${user.yogaPoses.pose3}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="Yoga Pose 3" /> Yoga Pose 3*</button></a>
                    <a href={user?.yogaPoses?.pose4 ? `${process.env.REACT_APP_URL}${user.yogaPoses.pose4}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="Yoga Pose 4" /> Yoga Pose 4*</button></a>
                    <a href={user?.yogaPoses?.pose5 ? `${process.env.REACT_APP_URL}${user.yogaPoses.pose5}` : 'img/profile-img.png'} target='_blank' rel="noopener noreferrer"><button className="document-update-btn"><img src="img/pdf.svg" alt="Yoga Pose 5" /> Yoga Pose 5*</button></a>
                  </div>
                </>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ViewUser
