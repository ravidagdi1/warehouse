import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import './Css/sideBar.css';

function SideBar() {
  const [openSubMenu, setOpenSubMenu] = useState(null);

  const handleToggleSubMenu = (menu) => {
    setOpenSubMenu(openSubMenu === menu ? null : menu);
  };
  
  const name = localStorage.getItem("name");
  const location = localStorage.getItem("location");

  return (
    <div className="col-md-3 left_col">
      <div className="left_col scroll-view">
        <div className="navbar nav_title" style={{ border: 0 }}>
          <NavLink to="/dashboard" className="site_title">
            <img src="img/logo.png" alt="Logo" />

          </NavLink>

        </div>
        <div className="clearfix" />
        <div id="sidebar-menu" className="main_menu_side hidden-print main_menu">
          <div className="menu_section">
            <ul className="nav side-menu">
            <li>
                <NavLink to="/dashboard" activeClassName="active">
                  <i className="fa fa-user" /> {`${name} `}
                </NavLink>
              </li>
              <li>
                <NavLink to="/dashboard" activeClassName="active">
                  <i className="fa fa-map-marker" /> {`${location}`}
                </NavLink>
              </li>
              <li>
                <NavLink to="/dashboard" activeClassName="active">
                  <i className="fa fa-home" /> Dashboard
                </NavLink>
              </li>

              <li>
                <a onClick={() => handleToggleSubMenu('userManager')}>
                  <i className="fa fa-user-circle-o" /> User Manager
                  <i className={`fa ${openSubMenu === 'userManager' ? 'fa-chevron-down' : 'fa-chevron-right'}`} style={{ float: 'right' }} />
                </a>
                {openSubMenu === 'userManager' && (
                  <ul style={{ listStyleType: 'none', paddingLeft: '20px' }}>
                    <li style={{ marginLeft: '35px', marginTop: '5px' }}>
                      <NavLink to="/users" className="sub-link" activeClassName="active">
                        Active Store Manager
                      </NavLink>
                    </li>
                    <li style={{ marginLeft: '35px', marginTop: '5px' }}>
                      <NavLink to="/trainer" className="sub-link" activeClassName="active">
                        Pending Approvals
                      </NavLink>
                    </li>
                  </ul>
                )}
              </li>
              <li>
                <NavLink to="/store" activeClassName="active">
                  <i className="fa fa-gear" /> Store Management
                </NavLink>
              </li>
              
              <li>
                <NavLink to="/settings" activeClassName="active">
                  <i className="fa fa-gear" /> Settings/Profile
                </NavLink>
              </li>
              <li>
                <NavLink to="/master" activeClassName="active">
                  <i className="fa fa-gear" /> Master List
                </NavLink>
              </li>
              <li>
                <NavLink to="/inventory" activeClassName="active">
                  <i className="fa fa-gear" /> Inventory
                </NavLink>
              </li>
              
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SideBar;
