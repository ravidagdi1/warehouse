import React, { useState, useEffect } from 'react';
import useAsync from '../hooks/useAsync';
import ContactServices from '../services/ContactServices';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css'; // Import React Quill styles

function TermCondition() {
  const { data, error, isLoading } = useAsync(ContactServices.getTermCondition);
  const [formValues, setFormValues] = useState({ termsAndCondition: '', termsAndConditionHindi: '', data: "termsAndCondition" });

  useEffect(() => {
    if (data) {
      setFormValues({
        termsAndCondition: data?.data?.English || '',
        termsAndConditionHindi: data?.data?.Hindi || '',
        data: "termsAndCondition"
      });
    }
  }, [data]);

  const handleInputChange = (name, value) => {
    setFormValues(prevValues => ({ ...prevValues, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await ContactServices.updateAppPolicy(formValues);
      alert('Terms and Conditions updated successfully!');
    } catch (error) {
      console.error('Failed to update Terms and Conditions:', error);
      alert('Failed to update Terms and Conditions. Please try again.');
    }
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div className="right_col" role="main">
      <div className="title-box">
        <h2>Term And Condition</h2>
      </div>
      <div className="container-box p-0 profile-container py-0">
        <div className="container-box-inner p-5">
          <div className="row">
            <form onSubmit={handleSubmit}>
              <div className="input-field">
                <label><b>English</b></label>
                <ReactQuill
                  theme="snow"
                  value={formValues.termsAndCondition}
                  onChange={(value) => handleInputChange('termsAndCondition', value)}
                  className="form-control"
                />
              </div>
              <div className="input-field">
                <label><b>Hindi</b></label>
                <ReactQuill
                  theme="snow"
                  value={formValues.termsAndConditionHindi}
                  onChange={(value) => handleInputChange('termsAndConditionHindi', value)}
                  className="form-control"
                />
              </div>
              <button className="submit-green-btn">SUBMIT</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TermCondition;
