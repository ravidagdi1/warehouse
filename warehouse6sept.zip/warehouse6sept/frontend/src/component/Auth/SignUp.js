import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminServices from '../../services/AdminServices';
import useAsync from '../../hooks/useAsync';
import LocationServices from '../../services/LocationServices';

function SignUp({ setIsAuthenticated, setRole }) {
  const [mobileOrEmail, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [selectedRole,setSelectedRole] = useState('');
  const [location, setLocation] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [name , setName] = useState('');
  const [store,setSelectedStore] = useState('');
  const navigate = useNavigate();
  
  const {data,error1,isLoading} = useAsync(LocationServices.getStore)
 
  
 console.log(data)
  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(mobileOrEmail, store)
    
    const data1 = await AdminServices.signUp({name:name,email: mobileOrEmail, password: password ,role:selectedRole,store:store ,passwordConfirm:confirmPassword});

  
    console.log(data1)
   if (data1.status === true) {
      localStorage.setItem('authToken', data1?.token);
      localStorage.setItem('userRole', data1?.data1?.userType);
      localStorage.setItem('name', data1?.data1?.name);
      localStorage.setItem('image', data1?.data1?.image);
      setIsAuthenticated(true);
      setRole('human');
      navigate('/dashboard');
   }else{
    setIsAuthenticated(true);
      setRole('human');
      navigate('/dashboard');
    setError("*Invalid Credentials");
   }
  };

  return (
    <div className="login-section">
      <div className="login-section-inner">
        <div className="row">
          <div className="col-md-6 pe-0">
            <div className="login-section-left">
              <h1>Sign Up</h1>
              <form className="user-login" >
              <div className="input-field mb-3">
                  <label htmlFor="name" className="form-label">Name</label>
                  <input
                    type="text"
                    className="form-control"
                    id="name"
                    placeholder=""
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />

                </div>
                
                <div className="input-field mb-3">
                  <label htmlFor="userEmail" className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="userEmail"
                    placeholder=""
                    value={mobileOrEmail}
                    onChange={(e) => setEmail(e.target.value)}
                  />

                </div>
                <div className="input-field mb-3">
                  <label htmlFor="password" className="form-label">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    placeholder=""
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                
                <div className="input-field mb-3">
                  <label htmlFor="password" className="form-label">Confirm Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    placeholder=""
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                  />
                </div>
                <div className="input-field mb-3">
                  <label htmlFor="password" className="form-label">Role</label>
                  <select
      className="form-select"
      value={selectedRole}
      onChange={(e)=>setSelectedRole(e.target.value)}
    >
        
      <option value="admin">Admin</option>
      <option value="user">User</option>
    </select>
                </div>
                <div className="input-field mb-3">
                  <label htmlFor="userEmail" className="form-label">Store Location</label>
                  <select
      className="form-select"
      value={store}
      onChange={(e)=>setSelectedStore(e.target.value)}
    >
      <option>Select Store</option>
        {data?.data?.data?.map((store,index)=>(
             <option value={store._id}>{`${store.name},${store.location} `}</option>
        ))}
      
    </select>

                </div>
                <h6 style={{ color: 'red' }}>{error}</h6>
                <div className="input-field mb-3">
                  <input
                    onClick={handleSubmit}
                    type="submit"
                    className="form-control"
                    id="login-btn"
                    value="Sign Up"
                  />
                </div>
              </form>
              
            </div>
          </div>
          {/* <div className="col-md-6 ps-0">
            <div className="login-section-right">
              <div className="logo-field">
                <img src="img/logo.png" alt="Logo" />
              </div>
              <div className="light-field px-4">
                <img src="img/cuate.svg" alt="Illustration" />
              </div>
            </div>
          </div> */}
        </div>
      </div>
    </div>
  );
}

export default SignUp;
