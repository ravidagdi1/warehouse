import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AdminServices from '../../services/AdminServices';

function Login({ setIsAuthenticated, setRole }) {
  const [mobileOrEmail, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(mobileOrEmail, password)
    try {
  

      const data = await AdminServices.login({email: mobileOrEmail, password: password});
    console.log(data)
   if (data.status === "success") {
      localStorage.setItem('authToken', data?.token);
      localStorage.setItem('userRole', data?.data?.user?.role);
      localStorage.setItem('name', data?.data?.user?.name);
      localStorage.setItem('store', data?.data?.user?.store[0]?.name);
      localStorage.setItem('location', data?.data?.user?.store[0]?.location);
      setIsAuthenticated(true);
      setRole(data?.data?.user?.role);
      navigate('/dashboard');
   }
    } catch (error) {

      setError(error.response.data.message); // Error message from the server
     
    }
    
  };

  return (
    <div className="login-section">
      <div className="login-section-inner">
        <div className="row">
          <div className="col-md-6 pe-0">
            <div className="login-section-left">
              <h1>Login</h1>
              <p></p>
              <form className="user-login" >
                <div className="input-field mb-3">
                  <label htmlFor="userEmail" className="form-label">Email</label>
                  <input
                    type="email"
                    className="form-control"
                    id="userEmail"
                    placeholder="example@example.com"
                    value={mobileOrEmail}
                    required = "true"
                    onChange={(e) => setEmail(e.target.value)}
                  />

                </div>
                <div className="input-field mb-3">
                  <label htmlFor="password" className="form-label">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    placeholder="••••••••••"
                    value={password}
                    required = "true"
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <h6 style={{ color: 'red' }}>{error}</h6>
                <div className="input-field mb-3">
                  <input
                    onClick={handleSubmit}
                    type="submit"
                    className="form-control"
                    id="login-btn"
                    value="Login"
                  />
                </div>
              </form>
              
            </div>
          </div>
          
        </div>
      </div>
    </div>
  );
}

export default Login;
