import React, { useEffect, useState } from 'react';
import useAsync from '../hooks/useAsync';
import UserServices from '../services/UserServices';
import ViewUser from './View Model/ViewUser';
import Modal from 'react-modal';
import UserStatus from './TogelButton/UserStatus';
import ReactPaginate from 'react-paginate';
import * as XLSX from 'xlsx';

Modal.setAppElement('#root');

function Trainer() {
  const { data, error, isLoading, run } = useAsync(UserServices.getAllUser);
  console.log(data);

  const [currentPage, setCurrentPage] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);

  useEffect(() => {
    if (data?.data?.data) {
      setFilteredUsers(data?.data?.data.filter((user)=>{return user.active !== true}));
    }
  }, [data]);

  const handleViewDetails = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const handlePageClick = ({ selected }) => {
    setCurrentPage(selected + 1);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    filterUsers(e.target.value);
  };

  const filterUsers = (query) => {
    if (query) {
      const filtered = filteredUsers.filter(user =>
        user?.name?.toLowerCase().includes(query.toLowerCase()) ||
        user?.email?.toString().includes(query.toString()) ||
        user?.location?.toLowerCase().includes(query.toLowerCase())
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(data?.data?.data.filter((user)=>{return user.active !== true}));
    }
  };

  const usersPerPage = 20;
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = filteredUsers?.slice(indexOfFirstUser, indexOfLastUser);

  const generateExcel = () => {
    const filteredData =data?.data?.data.map(user => ({
      userType: user.userType,
      name: user.name,
      email: user.email,
      status: user.status,
    }));

    const ws = XLSX.utils.json_to_sheet(filteredData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Users');
    XLSX.writeFile(wb, 'user_data.xlsx');
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString();

    return `${day}-${month}-${year}`;
  };

  return (
    <div className="right_col" role="main">
      <div className="title-box">
        <h2>Pending Approval<span className="badge bg-warning">{filteredUsers?.length}</span></h2>
      </div>
      <div className="sub-title-box">
        <div className="sub-title-box-left">
          <p>User List</p>
        </div>
        <div className="sub-title-box-right">
          <button className="excel-btn" onClick={generateExcel}>
            <img src="img/excel.svg" alt="Download" />Download
          </button>
        </div>
      </div>
      <div className="container-box px-0 user-manager">
        <div className="container-box-top-header px-4">
          <div className="container-box-top-header-left-2">
            <input
              type="search"
              name="search"
              placeholder="Search"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <button className="search-btn">Search</button>
          </div>
        </div>
        <div className="container-box-inner">
          <table id="example" className="table table-striped" style={{ width: '100%' }}>
            <thead>
              <tr>
                <th>#</th>
                <th>User Role</th>
                <th>Name</th>
                <th>Location</th>
                <th>Email</th>
                <th>Status</th>
                <th>More Details</th>
              </tr>
            </thead>
            <tbody>
              {currentUsers?.map((user, index) => (
                <tr key={user?._id}>
                  <td>{index + 1 + (currentPage - 1) * usersPerPage}</td>
                  <td><span className="usertype">{user?.role}</span></td>
                  <td>{user?.name}</td>
                  {/* <td>
                    <img
                      src={user?.image ? `${process.env.REACT_APP_URL}${user.image}` : 'img/profile-img.png'}
                      alt=""
                      style={{ height: '50px', width: '50px', objectFit: 'contain' }}
                    />
                  </td> */}
                  <td>{user?.location}</td>
                  <td className="email">{user?.email ? user.email : 'N/A'}</td>
                  {/* <td>{user?.createdAt ? formatDate(user.createdAt) : '-'}</td> */}
                  <td className="status-toggle"><UserStatus user={user} page={"user"} onSuccess={run} /></td>
                  <td>
                    <button
                      className="view-details-btn"
                      onClick={() => handleViewDetails(user)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pagination">
          <ReactPaginate
            pageCount={Math.ceil(filteredUsers?.length / usersPerPage)}
            pageRangeDisplayed={3}
            marginPagesDisplayed={1}
            onPageChange={handlePageClick}
            containerClassName={'pagination'}
            activeClassName={'active'}
            previousLabel={'Previous'}
            nextLabel={'Next'}
            breakLabel={'...'}
            breakClassName={'break-me'}
            initialPage={currentPage - 1}
            disableInitialCallback={true}
            pageLinkClassName={'page-link'}
            previousLinkClassName={'page-link'}
            nextLinkClassName={'page-link'}
            pageClassName={'page-item'}
            previousClassName={'page-item'}
            nextClassName={'page-item'}
            disabledClassName={'disabled'}
          />
        </div>
      </div>
      <Modal
        isOpen={isModalOpen}
        onRequestClose={closeModal}
        contentLabel="User Details"
        className="modal-content"
        overlayClassName="modal-overlay"
      >
        <ViewUser user={selectedUser} closeModal={closeModal} />
      </Modal>
    </div>
  );
}

export default Trainer;
