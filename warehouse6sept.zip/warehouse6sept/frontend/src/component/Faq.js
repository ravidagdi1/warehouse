import React, { useState, useEffect } from 'react';
import FaqServices from '../services/FaqServices';
import { Link } from 'react-router-dom';
import Modal from 'react-modal';
import FaqUpdate from './Update Model/UpdateFaq';
import DeleteButton from './Button/DeleteButton';

Modal.setAppElement('#root');

function FaqList() {
    const [faqs, setFaqs] = useState([]);
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedEdit, setSelectedEdit] = useState(null);

    useEffect(() => {
        fetchFaqs();
    }, []);

    const fetchFaqs = async () => {
        try {
            const response = await FaqServices.getAllFaq();
            if (response.status === true) {
                setFaqs(response.data);
            } else {
                alert('Failed to fetch FAQs');
            }
        } catch (error) {
            console.error('Error fetching FAQs', error);
        }
    };

    const handleEditDetails = (faq) => {
        setSelectedEdit(faq);
        setIsEditModalOpen(true);
    };

    const handleDelete = (faq) => {
        setSelectedEdit(faq);
        setIsDeleteModalOpen(true);
    };

    const closeDeleteModal = () => {
        setIsDeleteModalOpen(false);
        setSelectedEdit(null);
    };

    const closeEditModal = () => {
        setIsEditModalOpen(false);
        setSelectedEdit(null);
    };

    const onSuccess = () => {
        fetchFaqs();
        closeDeleteModal();
    };

    return (
        <div className="right_col" role="main">
            <div className="title-box">
                <h2>FAQs List <span className="badge bg-orange">{faqs.length}</span></h2>
                <div className="container-box-top-header-right">
                    <Link className="round-add-btn" to="/add-faq"><img src="img/plus.svg" alt="" /></Link>
                </div>
            </div>
            <div className="container-box px-5">
                <div className="title-box">
                    <h2>Frequently Asked Questions</h2>
                </div>
                <div className="tab-content" id="pills-tabContent">
                    <div className="faq-outer">
                        <div className="accordion" id="accordion-faq">
                            {faqs.map((faq, index) => (
                                <div className="accordion-item-outer" key={index}>
                                    <div className="accordion-item">
                                        <h2 className="accordion-header" id={`heading-${index}`}>
                                            <button
                                                className="accordion-button"
                                                type="button"
                                                data-bs-toggle="collapse"
                                                data-bs-target={`#collapse-${index}`}
                                                aria-expanded="false"
                                                aria-controls={`collapse-${index}`}
                                                style={{ position: 'relative' }}
                                            >
                                                <span className="qustn">Q :</span> <span>{faq.title}</span>
                                                <button
                                                    className="btn btn-default"
                                                    style={{
                                                        position: 'absolute',
                                                        backgroundColor: '#223973',
                                                        color: 'white',
                                                        right: '10%',
                                                        top: '50%',
                                                        transform: 'translateY(-50%)'
                                                    }}
                                                >
                                                    {faq.userFor}
                                                </button>
                                            </button>
                                        </h2>
                                        <div
                                            id={`collapse-${index}`}
                                            className="accordion-collapse collapse"
                                            aria-labelledby={`heading-${index}`}
                                            data-bs-parent="#accordion-faq"
                                        >
                                            <div className="accordion-body">
                                                <div className="faq-answer-inside">
                                                    <p>Answer :</p>
                                                    <p>{faq.description}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="faq-edit-grp">
                                        <button className="video-edit-btn" style={{ backgroundColor: '#15B71B', border: 'none', padding: '5px 10px', borderRadius: '5px' }} onClick={() => handleEditDetails(faq)}>
                                            <i className="fa fa-pencil" style={{ color: '#FFFFFF' }}></i>
                                        </button>

                                        <button className="video-delete-btn" onClick={() => handleDelete(faq)}>
                                            <i className="fa fa-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            <Modal
                isOpen={isEditModalOpen}
                onRequestClose={closeEditModal}
                contentLabel="Edit FAQ"
                className="modal-content"
                overlayClassName="modal-overlay"
            >
                <FaqUpdate selectedData={selectedEdit} closeModal={closeEditModal} onSuccess={onSuccess} />
            </Modal>
            <Modal
                isOpen={isDeleteModalOpen}
                onRequestClose={closeDeleteModal}
                contentLabel="Delete Confirmation"
                className="modal-content"
                overlayClassName="modal-overlay"
            >
                <DeleteButton data={selectedEdit} page="faq" closeModal={closeDeleteModal} onSuccess={onSuccess} />
            </Modal>
        </div>
    );
}

export default FaqList;
