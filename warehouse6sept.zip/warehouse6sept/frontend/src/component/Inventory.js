import React, { useEffect, useState } from 'react';
import useAsync from '../hooks/useAsync';
import Modal from 'react-modal';
import ReactPaginate from 'react-paginate';
import * as XLSX from 'xlsx';
import ProductServices from '../services/ProductServices';
import { Link } from 'react-router-dom';
import UserServices from '../services/UserServices';

Modal.setAppElement('#root');

function Inventory() {
  const { data, error, isLoading, run } = useAsync(ProductServices.getInventory);
  

  const [currentPage, setCurrentPage] = useState(1);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [store, setSelectedStore] = useState()
const [userProfile ,setUserProfile] =useState()
  useEffect(() => {
    if (data?.data?.data) {
      setFilteredUsers(data?.data?.data);
    }
    UserServices.getMyProfile().then((res)=>{
      setUserProfile(res?.data?.data)
    }).catch((error)=>{
      console.log(error)
    })
  }, [data]);

  const handleViewDetails = (user) => {
    setSelectedUser(user);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setSelectedUser(null);
  };

  const handlePageClick = ({ selected }) => {
    setCurrentPage(selected + 1);
  };

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    filterUsers(e.target.value);
  };

  const filterUsers = (query) => {
    console.log(query)
    if (query) {
      const filtered = filteredUsers.filter(user =>
        user?.partNo?.toString().includes(query.toString()) 
      );
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(data?.data?.data);
    }
  };

  const handleFilter = (id) =>{
    setSelectedStore(id)

    if (id) {
      const filtered = filteredUsers.filter(user =>
        user?.store === id
      ) 
      
      setFilteredUsers(filtered);
    } else {
      setFilteredUsers(data?.data?.data);
    }

  }

  
  


  const usersPerPage = 20;
  const indexOfLastUser = currentPage * usersPerPage;
  const indexOfFirstUser = indexOfLastUser - usersPerPage;
  const currentUsers = filteredUsers?.slice(indexOfFirstUser, indexOfLastUser);

  const generateExcel = () => {
    const filteredData =data?.data?.data.map(user => ({
      userType: user.userType,
      name: user.name,
      email: user.email,
      status: user.status,
    }));

    const ws = XLSX.utils.json_to_sheet(filteredData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Users');
    XLSX.writeFile(wb, 'user_data.xlsx');
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear().toString();

    return `${day}-${month}-${year}`;
  };

 

  
 console.log(userProfile)
  return (
    <div className="right_col" role="main">
      <div className="title-box">
        <h2>Inventory<span className="badge bg-warning">{filteredUsers?.length}</span></h2>
      
      </div>
      <div className="sub-title-box">
        <div className="sub-title-box-left">
          <p>Inventory</p>
        </div>
        <div className="sub-title-box-right">
          <button className="excel-btn" onClick={generateExcel}>
            <img src="img/excel.svg" alt="Download" />Download
          </button>
        </div>
      </div>
      <div className="container-box px-0 user-manager">
        <div className="container-box-top-header px-4">
          <div className="container-box-top-header-left-2">
            <input
              type="search"
              name="search"
              placeholder="Search"
              value={searchQuery}
              onChange={handleSearchChange}
            />
            <button className="search-btn">Search</button>
          </div>

          <div className="container-box-top-header-left-2">
          <select
      className="form-select"
      value={store}
      onChange={(e)=>handleFilter(e.target.value)}
    >
      <option>Select Store</option>
        {userProfile?.store?.map((store,index)=>(
             <option  value={store._id}>{`${store.name},${store.location} `}</option>
        ))}
      
    </select>

          </div>
        </div>
        <div className="container-box-inner">
          <table id="example" className="table table-striped" style={{ width: '100%' }}>
            <thead>
              <tr>
                <th>#</th>
                <th>Part No.</th>
                <th>Image</th>
                <th>Category</th>
                <th>SubCategory</th>
                <th>Description</th>
                <th>Unit</th>
                <th>L/p</th>                
                <th>Qty Auth</th>
                <th>Total Recive</th>
                <th>Total Transfer</th>
                <th>Total MIV</th>
                <th>Critical Stock Qty</th>
                <th>Current Stock</th>
                <th>Recive Persentage</th>
                <th>Remark</th>
              </tr>
            </thead>
            <tbody>
              {currentUsers?.map((user, index) => (
                <tr key={user?._id}>
                  <td>{index + 1 + (currentPage - 1) * usersPerPage}</td>
                  <td>{user?.masterItem?.partNo}</td>
                  <td>
                    <img
                      src={user?.image ? `http://localhost:3001/img/product/${user?.masterItem?.image}` : 'img/profile-img.png'}
                      alt=""
                      style={{ height: '50px', width: '50px', objectFit: 'contain' }}
                    />
                  </td>
                  <td>{user?.masterItem?.category}</td>
                  <td className="email">{user?.masterItem?.subCategory}</td>
                  {/* <td>{user?.createdAt ? formatDate(user.createdAt) : '-'}</td> */}
                  <td className="email">{user?.masterItem?.description}</td>
                  <td className="email">{user?.masterItem?.unit}</td>
                  <td className="email">{user?.lp}</td>
                  <td className="email">{user?.qtyAuth}</td>
                  <td className="email">{user?.totalRecive}</td>
                  <td className="email">{user?.transfer}</td>
                  <td className="email">{user?.Miv}</td>
                  <td className="email">{user?.criticalStockQty}</td>
                  <td className="email">{user?.currentStock}</td>                 
                  <td className="email">{user?.recivePercentage}</td>
                  <td className="email">{user?.remark}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="pagination">
          <ReactPaginate
            pageCount={Math.ceil(filteredUsers?.length / usersPerPage)}
            pageRangeDisplayed={3}
            marginPagesDisplayed={1}
            onPageChange={handlePageClick}
            containerClassName={'pagination'}
            activeClassName={'active'}
            previousLabel={'Previous'}
            nextLabel={'Next'}
            breakLabel={'...'}
            breakClassName={'break-me'}
            initialPage={currentPage - 1}
            disableInitialCallback={true}
            pageLinkClassName={'page-link'}
            previousLinkClassName={'page-link'}
            nextLinkClassName={'page-link'}
            pageClassName={'page-item'}
            previousClassName={'page-item'}
            nextClassName={'page-item'}
            disabledClassName={'disabled'}
          />
        </div>
      </div>
      
    </div>
  );
}

export default Inventory;
