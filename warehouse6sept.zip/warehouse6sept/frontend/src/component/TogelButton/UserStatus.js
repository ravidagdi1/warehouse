import React, { useState } from 'react';
import UserServices from '../../services/UserServices';
import ProductServices from '../../services/ProductServices';
const UserStatus = ({ user,page ,onSuccess}) => {
  // Initialize the state based on the user's status
  const [isChecked, setIsChecked] = useState(user?.status === 'active');

  // Handle checkbox toggle
  const handleToggle = async () => {
    const newStatus = !isChecked ? "active" : "inactive";
    setIsChecked(!isChecked);
    if(page === 'user'){
      const res = await UserServices.updateUser(user._id, {
        active: newStatus
      });

      onSuccess();
    }else if(page === 'store'){
      const res = await ProductServices.updateStore(user._id,{
        status : newStatus
      })
    }
  };

  return (
   
      <div className="check-box">
        <input
          type="checkbox"
          checked={isChecked}
          onChange={handleToggle}
        />
      </div>
    
  );
};

export default UserStatus;
