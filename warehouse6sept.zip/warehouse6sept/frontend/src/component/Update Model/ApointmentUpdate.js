import React, { useState, useEffect } from 'react';
import AppointmentServices from '../../services/AppointmentServices';

function AppointmentUpdate({ selectedData, closeModal, onSuccess }) {
  // console.log(selectedData);
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    age: '',
    fees: '',
    date: '',
    duration: '',
    appointmentStatus: '',
    bookingId:'',
    doctorName: '',
  });
console.log(selectedData)
  useEffect(() => {
    if (selectedData) {
      setFormData({
        name: selectedData?.user?.name || '',
        address: selectedData?.user?.address || '',
        age: selectedData?.user?.age || '',
        fees: selectedData?.trainer?.fee || '',
        bookingId: selectedData?.bookingId|| '',
        date: selectedData?.date ? formatDate(selectedData.date) : '',  
        duration: selectedData?.duration || '',
        appointmentStatus: selectedData?.status || '',
        doctorName: selectedData?.trainer?.name || '',
      });
    }
  }, [selectedData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  function formatDate(isoString) {
    const date = new Date(isoString);
    const formattedDate = date.toISOString().split('T')[0]; // Format date as YYYY-MM-DD
    return formattedDate;
  }

  

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const updatedData = {
        date: formData.date,
        duration: formData.duration,
      };

      const response = await AppointmentServices.updateApointment(selectedData._id, updatedData);
      if (response.status === true) {
        alert('Appointment updated successfully');
        onSuccess();
        closeModal();
      } else {
        alert('Something went wrong');
      }
    } catch (error) {
      console.error('Failed to update appointment', error);
      alert('Failed to update appointment');
    }
  };

  return (
    <div className="modal fade edit-box show d-block" id="editModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Appointment Edit</h5>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={closeModal} />
          </div>
          <div className="modal-body">
            <div className="container-box px-5">
              <div className="container-box-inner">
                <div className="page-details">
                  <form onSubmit={handleSubmit}>
                    <div className="row">
                      <div className="col-sm-12">
                        <div className="input-field">
                          <label>Name</label>
                          <input type="text" name="name" className="form-control" value={formData.name} readOnly />
                        </div>
                      </div>
                      <div className="col-sm-12">
                        <div className="input-field">
                          <label>Address</label>
                          <textarea
                            className="form-control video-desc"
                            name="address"
                            value={formData.address}
                            readOnly
                          />
                        </div>
                      </div>
                      <div className="col-sm-3">
                        <div className="input-field">
                          <label>Age</label>
                          <input type="text" name="age" className="form-control" value={formData.age} readOnly />
                        </div>
                      </div>
                      <div className="col-sm-3">
                        <div className="input-field">
                          <label>Fees</label>
                          <input type="text" name="fees" className="form-control" value={formData.fees} readOnly />
                        </div>
                      </div>
                      <div className="col-sm-3">
                        <div className="input-field">
                          <label>Online Fees</label>
                          <input type="text" name="onlineFee" className="form-control" value={formData.onlineFee} readOnly />
                        </div>
                      </div>
                      <div className="col-sm-3">
                        <div className="input-field">
                          <label>Booking No.</label>
                          <input type="text" name="bookingId" className="form-control" value={formData.bookingId} readOnly />
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="input-field">
                          <label>Appointment Date</label>
                          <input type="date" name="date" className="form-control" value={formData.date} onChange={handleChange} />
                        </div>
                      </div>
                      <div className="col-md-3">
                        <div className="input-field">
                          <label>Time</label>
                          <input type="text" name="duration" className="form-control" value={formData.duration} onChange={handleChange} />
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="input-field">
                          <label>Appointment Status</label>
                          <input type="text" name="appointmentStatus" className="form-control" value={formData.appointmentStatus} readOnly />
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="input-field">
                          <label>Trainer Name</label>
                          <input type="text" name="doctorName" className="form-control" value={formData.doctorName} readOnly />
                        </div>
                      </div>
                    </div>
                    <button className="submit-green-btn">SUBMIT</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AppointmentUpdate;
