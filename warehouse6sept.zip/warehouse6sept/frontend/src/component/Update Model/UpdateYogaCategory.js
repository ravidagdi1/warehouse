import React, { useState, useEffect } from 'react';
import YogaCategoryServices from '../../services/YogaCategoryServices.js';

function UpdateYogaCategory({ selectedData, closeModal, onSuccess }) {
  const [formValues, setFormValues] = useState({
    name: '',
  });

  useEffect(() => {
    if (selectedData) {
      setFormValues({
        name: selectedData.name || '',
      });
    }
  }, [selectedData]);

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const res = await YogaCategoryServices.updateYogaCategory(selectedData._id, { name: formValues.name });
      if (res.status === true) {
        alert('Category updated successfully');
        onSuccess();
        closeModal();
      } else {
        alert('Something went wrong');
      }
    } catch (error) {
      console.error('Failed to update category', error);
      alert('Failed to update category');
    }
  };

  return (
    <div className="modal fade edit-box show d-block" id="editModal" tabIndex={-1} aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Edit Category</h5>
            <button type="button" className="btn-close" data-bs-dismiss="modal" onClick={closeModal} aria-label="Close" />
          </div>
          <div className="modal-body px-5 pb-0">
            <div className="container-box px-5">
              <div className="container-box-inner">
                <div className="page-details">
                  <form onSubmit={handleSubmit}>
                    <div className="input-field">
                      <label>Title*</label>
                      <input
                        type="text"
                        name="name"
                        className="form-control"
                        value={formValues.name}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                    <button className="submit-green-btn" type="submit">
                      SUBMIT
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UpdateYogaCategory;
