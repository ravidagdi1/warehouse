import requests from "./httpService";

const LocationServices = {

    getLocation : async () =>{
        return requests.get(`/location`);
    },
    createLocation : async (body) =>{
        return requests.post(`/location`,body);
    },
    deleteLocation : async (id) =>{
        return requests.delete(`/location/${id}`);
    },
    updateLocation : async (id ,body) => {
        return requests.patch(`/location/${id}`,body)
    },
    getStore: async() => {
        return requests.get(`/store`)
    }

}

export default LocationServices;