import requests from "./httpService";

const ProductServices = {

    AddProduct : async (body) =>{
        return requests.post(`/masterlist`,body);
    },

    AddCategory : async (body) =>{
        return requests.post(`/category`,body);
    },

    getAllCategory : async () =>{
        return requests.get(`/category`);
    },
    UpdateCategory : async (id,body) =>{
        return requests.put(`/category/${id}`,body);
    },
    deleteCategory : async (id) =>{
        return requests.delete(`/category/${id}`);
    },

    getAllProduct : async () =>{
        return requests.get(`/masterlist`);
    },
    AddInventory : async (body)=>{
        console.log(body)
        return requests.post(`/inventory`,body)
    },

    updateProduct : async (id,body) =>{
        return requests.put(`/product/${id}`,body);
    },
    deleteProduct : async (id) =>{
        return requests.delete(`/product/${id}`);
    },
    getInventory : async () =>{
        return requests.get(`/inventory`);
    },
    getAllStore : async () =>{
        return requests.get(`/store`);
     },
    
    updateStore : async (id,body) =>{
        return requests.put(`/store/${id}`,body);
    }
    
}
export default ProductServices;